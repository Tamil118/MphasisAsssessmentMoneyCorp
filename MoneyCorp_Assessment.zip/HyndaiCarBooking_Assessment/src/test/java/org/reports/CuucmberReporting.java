package org.reports;

import java.io.File;
import java.util.ArrayList;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

public class CuucmberReporting {
	
	public static void generateReport(String json) {
		File f = new File("C:\\Users\\LENOVO\\newEclipseWorkspe\\HyndaiCarBooking_Assessment\\target");
		Configuration c = new Configuration(f, "Hyundai Car Booking Module");
		c.addClassifications("Browser name", "Chrome");
		c.addClassifications("platformName", "Windows");
		c.addClassifications("Mode", "Assessment");
		
		ArrayList<String> al = new ArrayList();
		al.add(json);
		
		ReportBuilder r = new ReportBuilder(al, c);
		r.generateReports();
	}

}
