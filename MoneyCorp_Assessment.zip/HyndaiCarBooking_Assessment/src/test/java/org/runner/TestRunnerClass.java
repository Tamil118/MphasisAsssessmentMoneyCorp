package org.runner;

import org.junit.AfterClass;
import org.junit.runner.RunWith;
import org.reports.CuucmberReporting;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="C:\\Users\\LENOVO\\newEclipseWorkspe\\HyndaiCarBooking_Assessment\\src\\test\\resources\\Features\\MoneyCorp.feature", 
glue="org.steps",
dryRun = false,
monochrome=true,
plugin="json:C:\\Users\\LENOVO\\newEclipseWorkspe\\HyndaiCarBooking_Assessment\\target\\Sample.json")
public class TestRunnerClass {
//	
//	@AfterClass
//	public static void tco() {
//		CuucmberReporting.generateReport("C:\\Users\\LENOVO\\newEclipseWorkspe\\HyndaiCarBooking_Assessment\\target\\Sample.json");
//	}

}
