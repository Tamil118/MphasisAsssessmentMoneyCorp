package org.base;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.sl.In;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {

	public static WebDriver driver;

	public static void launchUrl() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://www.moneycorp.com/en-gb/");
	}

	public static void enterText(WebElement element, String text) {
		element.sendKeys(text);
	}

	public static void buttonClick(WebElement element) {
		element.click();
	}

	public static void selectOptionFromDropDownUsingIndex(WebElement element, int index) {
		Select s = new Select(element);
		s.selectByIndex(index);
	}

	public static void selectByValue(WebElement element, String value) {
		Select s = new Select(element);
		s.selectByValue(value);
	}
	
	public static void selectByVisibleText(WebElement element, String text) {
		Select s = new Select(element);
		s.selectByVisibleText(text);
	}
	
	public static List<WebElement> getAllOptions(WebElement element){
		Select s = new Select(element);
		return s.getOptions();
	}
	
	public static void quitDriver() {
		driver.quit();
	}
	
	

}
