package org.steps;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.pages.ForeignExchangePage;
import org.pages.Homepage;

import io.cucumber.java.en.*;
import junit.framework.Assert;

public class StepDefintionClass extends BaseClass{
	
	Homepage h;
	ForeignExchangePage f;
	
	@Given("user navigates to the url")
	public void user_navigates_to_the_url() {
	   launchUrl();
	   String title = driver.getCurrentUrl();
	   Assert.assertEquals(title.contains("money"), true);
	   
	}
	@When("User changes the language and region to English and USA")
	public void user_changes_the_language_and_region_to_english_and_usa() {
	   h = new Homepage();
	   buttonClick(h.getLanguageSelect());
	   buttonClick(h.getUsLanguage());
	    
	}
	@When("User clicks on the find out more in Foreign Exchange")
	public void user_clicks_on_the_find_out_more_in_foreign_exchange() throws InterruptedException {
//		JavascriptExecutor js = (JavascriptExecutor)driver;
//		js.executeScript("arguments[0].scrollIntoView(true)", h.getFindOutMore());
		WebElement findElement = driver.findElement(By.xpath("(//button[@aria-label='Close'])[4]"));
		findElement.click();
//		WebDriverWait w = new WebDriverWait(driver, 30);
//		WebElement until = w.until(ExpectedConditions.elementToBeClickable(findElement));
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", h.getFindOutMore());
	}
	
	@Then("user validates the Foreign Exchange page")
	public void user_validates_the_foreign_exchange_page() {
		f = new ForeignExchangePage();
		String text = f.getText().getText();
		Assert.assertEquals(text.contains("Foreign exchange solutions"), true);
	}
	@When("user enters {string} in that page")
	public void user_enters_in_that_page(String string) throws AWTException {
	   enterText(f.getTextBox(), "international payments");
	   Robot r = new Robot();
	   r.keyPress(KeyEvent.VK_ENTER);
	   r.keyRelease(KeyEvent.VK_ENTER);
	    
	}
	@Then("user validates the page")
	public void user_validates_the_page() {
	   boolean contains = driver.getCurrentUrl().contains("international");
	   Assert.assertEquals(true, contains);
	    
	}
	@Then("user validates each article present in the page")
	public void user_validates_each_article_present_in_the_page() throws InterruptedException {
	   List<WebElement> links = f.getLinks();
	   String text = links.get(0).getText();
		   links.get(0).click();
		   WebElement findElement = driver.findElement(By.xpath("//h1[@class='u-text-display u-text-h1@l']"));
		   String text2 = findElement.getText();
		   Assert.assertEquals(text, text2);
		   System.out.println("Article link is verified");
		   Thread.sleep(3000);
		   driver.close();
	    
	}
}
