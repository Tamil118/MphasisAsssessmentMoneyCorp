package org.pages;

import java.util.List;

import org.base.BaseClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ForeignExchangePage extends BaseClass{

	public ForeignExchangePage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//h1[text()='Foreign exchange solutions for your business']")
	private WebElement text;
	
	@FindBy(xpath="(//div[@class='c-header__search']//input[@type='text' and @id='nav_search'])[2]")
	private WebElement textBox;
	
	@FindBy(xpath="//div[@class='results']//a")
	private List<WebElement> links;

	public WebElement getText() {
		return text;
	}

	public void setText(WebElement text) {
		this.text = text;
	}

	public WebElement getTextBox() {
		return textBox;
	}

	public void setTextBox(WebElement textBox) {
		this.textBox = textBox;
	}

	public List<WebElement> getLinks() {
		return links;
	}

	public void setLinks(List<WebElement> links) {
		this.links = links;
	}
	
	
	
}
