package org.pages;

import org.base.BaseClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Homepage  extends BaseClass {
	
	public Homepage() {
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="//div[@class='nav-inner-languages']")
	private WebElement languageSelect;
	
	@FindBy(xpath="//a[@aria-label='USA English']")
	private WebElement usLanguage;
	
	@FindBy(xpath="//h3[text()='Foreign exchange solutions']/..//a")
	private WebElement findOutMore;

	public WebElement getLanguageSelect() {
		return languageSelect;
	}

	public void setLanguageSelect(WebElement languageSelect) {
		this.languageSelect = languageSelect;
	}

	public WebElement getUsLanguage() {
		return usLanguage;
	}

	public void setUsLanguage(WebElement usLanguage) {
		this.usLanguage = usLanguage;
	}

	public WebElement getFindOutMore() {
		return findOutMore;
	}

	public void setFindOutMore(WebElement findOutMore) {
		this.findOutMore = findOutMore;
	}
	
	
	
	
	
	

}
