package org.login;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.response.Response;

public class Execution  extends BaseClass{
	
	@Test(dataProvider="SampleData")
	private void tc0(String status) {
		requestObject("https://www.boredapi.com/");
		addQueryParameter("type", status);
		Response responseObject = responseObject("GET", "api/activity");
		printResponseBody(responseObject);
		Object object = responseObject.jsonPath().get("type");
		String obj = (String)object;
		boolean contains = obj.contains(status);
		Assert.assertEquals(true, contains);
		System.out.println("Validated");
	}
	
	@DataProvider(name="SampleData")
	private Object[] dataProvider(){
		return new Object[] {"music", "social"};
	}

}
