package org.login;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BaseClass {

	public static RequestSpecification rs;

	public static void requestObject(String baseURI) {
		RestAssured.baseURI = baseURI;
		rs = RestAssured.given();
	}

	public static void addQueryParameter(String parameterName, String parameterValue) {
		rs.queryParam(parameterName, parameterValue);
	}

	public static Response responseObject(String requestType, String resources) {
		if (requestType.equals("GET")) {
			return rs.request(Method.GET, resources);
		} else if (requestType.equals("POST")) {
			return rs.request(Method.POST, resources);
		} else if (requestType.equals("PUT")) {
			return rs.request(Method.PUT, resources);
		} else {
			return rs.request(Method.DELETE, resources);

		}
	}

	public static void printResponseBody(Response response) {
		String asPrettyString = response.getBody().asPrettyString();
		System.out.println(asPrettyString);
	}

}
